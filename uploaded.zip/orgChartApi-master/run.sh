cd ./build && ./org_chart
